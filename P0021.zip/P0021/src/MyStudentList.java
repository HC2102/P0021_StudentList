import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//@author HE170417
public class MyStudentList {
    protected ArrayList<Student> list = new ArrayList<>();
    Scanner sc1 = new Scanner(System.in);
    //=====================Create=====================
    public void CreateStudent(int amount) {
        String tmp;
        for (int i = 0; i < amount; i++) {
            try {
                if (i != 0 && i % 2 == 0) {
                    System.out.println("Do you want to continues? (Y/N)");
                    tmp = sc1.nextLine().toUpperCase();
                    if (tmp.compareTo("N") == 0) break;
                    else if (tmp.compareTo("Y") != 0) throw new Exception("Input invalid");
                }
                System.out.println(i + 1);
                list.add(inputStudentData());
            } catch (Exception e) {
                System.out.println(e);
                i--;
            }
        }
    }
    public Student inputStudentData() {
        Student studentTmp = new Student();
        while (true) {
            System.out.print("Please enter student name: ");
            studentTmp.setStudentName(sc1.nextLine());
            if (isStudentNameValid(studentTmp.getStudentName())) break;
            else System.out.println("Student name is invalid");
        }
        while (true) {
            try {
                System.out.print("ID: ");
                studentTmp.setId(sc1.nextLine());
                if (findById(studentTmp.getId()) == null) break;
                else System.out.println("This Id is already taken");
            } catch (Exception e) {
                System.out.println("Invalid: " + e);
            }
        }
        while (true) {
            try {
                System.out.print("Semester: ");
                studentTmp.setSemester(Integer.parseInt(sc1.nextLine()));
                if (studentTmp.getSemester() < 10 && studentTmp.getSemester() > 0) break;
                else System.out.println("Semester must be between 0 and 9");
            } catch (Exception e) {
                System.out.println("Invalid: " + e);
            }
        }
        while (true) {
            try {
                System.out.print("Course name: ");
                studentTmp.setCourseName(sc1.nextLine());
                if (isCourseNameValid(studentTmp.getCourseName())) break;
                else System.out.println("Course must be in 1 of 3 courses only: Java, .Net, C/C++");
            } catch (Exception e) {
                System.out.println("Invalid: " + e);
            }
        }
        System.out.println("Complete");
        return studentTmp;
    }
    //=====================Report=====================
    public void traverse() {
        if (list.isEmpty()) System.out.println("List is empty!");
        for (Student student : list) {
            System.out.println(student.toString());
        }
    }
    //=====================Find=====================
    public Student findById(String targetId) {
        for (Student student : list) {
            if (student.getId().compareToIgnoreCase(targetId) == 0) {
                return student;
            }
        }
        return null;
    }
    public ArrayList<Student> findByName(ArrayList<Student> list, String targetName) {
        ArrayList<Student> list1 = new ArrayList<>();
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getStudentName().toLowerCase().contains(targetName.toLowerCase())){
                list1.add(list.get(i));
            }
        }
        return list1;
    }
    //=====================Sort=====================
    public void sortByName1(ArrayList<Student> list){
        Collections.sort(list, new Comparator<Student>() {
            @Override
            public int compare(Student student, Student t1) {
                return student.getStudentName().compareToIgnoreCase(t1.getStudentName());
            }
        });
    }
    //=====================Delete=====================
    public void deleteById(String id) {
        if (findById(id) == null) {
            System.out.println("ID not found!");
            return;
        }
        list.remove(findById(id));
    }
    //=====================Validator=====================
    boolean isCourseNameValid(String courseName) {
        String[] pattern = {"JAVA", ".NET", "C/C++"};
        for (String i : pattern) {
            if (i.compareToIgnoreCase(courseName) == 0) return true;
        }
        return false;
    }
    boolean isStudentNameValid(String name) {
        Pattern pattern = Pattern.compile("[^a-zA-Z\\s]");
        Matcher matcher = pattern.matcher(name);
        return !matcher.find();
    }
    //=====================Miscellaneous=====================
    ArrayList<Student> getList() {
        return list;
    }
}